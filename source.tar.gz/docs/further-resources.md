---
author: [Felix Pojtinger]
date: "2022-02-01"
subject: "Uni IT Security Further Resources"
keywords: [security-fundamentals, it-security, hdm-stuttgart]
subtitle: "Further Resources for the IT security course at HdM Stuttgart"
lang: "en"
---

## Uni IT Security Further Resources

You can find Anki cards here:

- [Jakob Waibel's Anki Cards](https://ankiweb.net/shared/info/1790561246)
- [Daniel Hiller's Summary](https://drive.google.com/file/d/1RVpckc8Sr3n-aAW3yJ3yGFfrdnjvyF1b/view?usp=sharing)
